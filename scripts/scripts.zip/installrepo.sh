


BOOT_IMAGE=/vmlinuz-4.1.0-trunk-amd64 root=/dev/mapper/kloption-root ro initrd=/install/initrd.gz quiet

#!/bin/bash