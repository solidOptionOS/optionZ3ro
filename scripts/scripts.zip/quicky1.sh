#!/bin/bash
airodump-ng --showack -aMU --wps --band abg wlan1 -c 1,6,9,11 -w ~/Enslave/Caps/quicky-capture
