#!/bin/bash
echo "blacklisting b43 and ssb "
echo "blacklist ssb" >> /etc/modprobe.d/blacklist.conf && echo "blacklist bcma" >> /etc/modprobe.d/blacklist.conf && echo "blacklist b43" >> /etc/modprobe.d/blacklist.conf && echo "blacklist brcmsmac" >> /etc/modprobe.d/blacklist.conf
