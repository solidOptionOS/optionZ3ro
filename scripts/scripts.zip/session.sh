#!/bin/bash
$session

bssid = 11:22:#3:44:55
source
dest.
mac
spoofed
:wq

