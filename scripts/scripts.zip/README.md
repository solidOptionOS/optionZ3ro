# OS-Scripts #

Personal collection of Operating System (OS) scripts _(and related things)_.

- - -

## Kali v2

Kali 2.x _(Debian 8)_
![](https://i.imgur.com/oJxBQNy.png)
_Left GNOME 3.10, right XFCE 4.10. Both with conky._

- - -

## Kali v1

Kali 1.x _(Debian 7)_
![](https://i.imgur.com/8D69XMO.png)
_Left GNOME 3.4, right XFCE 4.8. Both with conky._

_...Misc screenshots of **JUST** XFCE (no conky/ZSH/Tweaks)_
![](https://i.imgur.com/P2Oj28f.png)
